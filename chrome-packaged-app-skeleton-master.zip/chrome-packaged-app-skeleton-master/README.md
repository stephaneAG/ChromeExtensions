Skeleton application for google chrome with custom toolbar.
